package Init;

import Core.E_Color;
import Core.ExceptionNumberInput;
import Core.Guitar;
import Core.Instrument;
import Core.Piano;
import Core.Store;

public class Main {

	public static void main(String[] args)  {
		Store store = null;
		@SuppressWarnings("unused")
		Store store2 = null;
		try {
			store = new Store(111, "javaMusic");
			store2=new Store(1111, "tlvMusic");
		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
		
		store.addInstrument(new Piano(100, 100, E_Color.black, 125, 1994, "ISR", 50, false));
		store.addInstrument(new Piano(101, 100, E_Color.black, 125, 1994, "ISR", 50, false));
		store.addInstrument(new Piano(102, 100, E_Color.black, 250, 2000, "ISR", 100, true));
		store.addInstrument(new Piano(103, 100, E_Color.black, 128, 1994, "ISR", 50, false));
		store.addInstrument(new Piano(104, 100, E_Color.black, 230, 2000, "ISR", 100, true));
		store.loadGuitarsFromFile("input.txt");

		for(Instrument i : store.getInstruments())
			System.out.println(i);
		store.saveGuitarsListToFile(store.allGuitarsSortedByRating());
		
		try {
			store.addInstrumentAmount(store.getInstruments().get(0), 1);
		} catch (ExceptionNumberInput e)
		{
			System.out.println(e.getMessage());
		}
		Guitar g = new Guitar(159, 10, E_Color.purple, 10, 0, null, 0, false, 0);

		try {
			g.calcRating();
		}
		catch(ArithmeticException a) {
			System.out.println(a.getMessage());
		}
	
	}




}
