package Core;

public class Flute extends Instrument{

	public Flute(int number, double price, E_Color color, double weight, int yearProd, String country,
			int numOfInstruments) {
		super(number, price, color, weight, yearProd, country, numOfInstruments);
	}

	@Override
	public String toString() {
		return "Flute : "+super.toString();
	}

	@Override
	public double calcRating() {
		if(this.numOfInstruments>0)
			return this.price/this.numOfInstruments*30;
		return 0;
	}

}
