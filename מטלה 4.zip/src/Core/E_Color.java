package Core;

public enum E_Color {
white,black,red,blue,green,purple;
}
