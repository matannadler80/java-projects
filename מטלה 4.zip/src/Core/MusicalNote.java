package Core;

import java.util.Objects;

public class MusicalNote {
	
	private int noteNumber;

	private String info;

	public int getNoteNumber() {
		return noteNumber;
	}

	public void setNoteNumber(int noteNumber) {
		this.noteNumber = noteNumber;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public MusicalNote(int noteNumber, String info) {
		this.noteNumber = noteNumber;
		this.info = info;
	}

	@Override
	public int hashCode() {
		return Objects.hash(noteNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MusicalNote other = (MusicalNote) obj;
		return noteNumber == other.noteNumber;
	}

	@Override
	public String toString() {
		return "MusicalNote [noteNumber=" + noteNumber + ", info=" + info + "]";
	}
	
	
}
