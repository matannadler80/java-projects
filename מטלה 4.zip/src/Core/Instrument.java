package Core;

import java.util.ArrayList;
import java.util.Objects;

public abstract class Instrument implements IRating{
	
	protected int number;
	
	protected double price;
	
	protected E_Color color;
	
	protected double weight;
	
	protected int yearProd;
	
	protected String country;
	
	protected int numOfInstruments;
	
	protected ArrayList<MusicalNote> notes;

	public Instrument(int number, double price, E_Color color, double weight, int yearProd, String country,
			int numOfInstruments) {
		this.number = number;
		this.price = price;
		this.color = color;
		this.weight = weight;
		this.yearProd = yearProd;
		this.country = country;
		this.numOfInstruments = numOfInstruments;
		this.notes=new ArrayList<>();
	}

	@Override
	public int hashCode() {
		return Objects.hash(number);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Instrument other = (Instrument) obj;
		return number == other.number;
	}

	@Override
	public String toString() {
		return "number=" + number + ", price=" + price + ", color=" + color + ", weight=" + weight
				+ ", yearProd=" + yearProd + ", country=" + country + ", numOfInstruments=" + numOfInstruments;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public E_Color getColor() {
		return color;
	}

	public void setColor(E_Color color) {
		this.color = color;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getYearProd() {
		return yearProd;
	}

	public void setYearProd(int yearProd) {
		this.yearProd = yearProd;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getNumOfInstruments() {
		return numOfInstruments;
	}

	public void setNumOfInstruments(int numOfInstruments) {
		this.numOfInstruments = numOfInstruments;
	}

	public ArrayList<MusicalNote> getNotes() {
		return notes;
	}

	public void setNotes(ArrayList<MusicalNote> notes) {
		this.notes = notes;
	}
	
	
	
	
	
	

}
