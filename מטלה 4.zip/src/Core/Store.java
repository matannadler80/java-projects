package Core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Store {

	private int storeId;

	private String storeName;

	private ArrayList<Instrument> instruments;

	public Store(int storeId, String storeName) throws ExceptionNumberInput
	{
		int length = 0;
		long temp = 1;
		while (temp <= storeId)
		{
		    length++;
		    temp *= 10;
		}
		if(length!=3)
		{
			throw new ExceptionNumberInput("Wrong input for store number! must be number with 3 digits only!");
		}
		this.storeId = storeId;
		this.storeName = storeName;
		this.instruments=new ArrayList<>();
	}

	public int getStoreId() {
		return storeId;
	}



	public ArrayList<Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(ArrayList<Instrument> instruments) {
		this.instruments = instruments;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	@Override
	public int hashCode() {
		return Objects.hash(storeId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Store other = (Store) obj;
		return storeId == other.storeId;
	}

	@Override
	public String toString() {
		return "Store [storeId=" + storeId + ", storeName=" + storeName + "]";
	}

	public boolean addInstrument(Instrument i) {
		
		if(i!=null && !this.instruments.contains(i)) {
			return this.instruments.add(i);

		}
		return false;
	}


	public boolean removeInstrument(Instrument i) {
		if(i!=null && this.instruments.contains(i)) {
			int ind = this.instruments.indexOf(i);
			return this.instruments.remove(this.instruments.get(ind));
		}
		return false;
	}

	public boolean addInstrumentAmount(Instrument inst,int amount) throws ExceptionNumberInput {
		
		if(inst!=null) {
			if(this.instruments.contains(inst))
			{
				if(inst.getNumOfInstruments()>amount)
				{
					throw new ExceptionNumberInput("Amount input isn't valid");
				}
				int ind = this.instruments.indexOf(inst);
				this.instruments.get(ind).numOfInstruments=amount;
				return true;
			}
			else {
				inst.numOfInstruments=amount;
				addInstrument(inst);
				return true;
			}
		}
		return false;
	}

	public ArrayList<Guitar> allElectricGuitars(){
		ArrayList<Guitar> guitars=new ArrayList<Guitar>();
		for(Instrument i : this.instruments) {
			if(i!=null && i instanceof Guitar) {
				Guitar g = (Guitar) i;
				if(g.isElectric()) {
					guitars.add(g);
				}

			}
		}
		return guitars;
	}

	public ArrayList<Guitar> allGuitarsSortedByRating(){
		ArrayList<Guitar> guitars=new ArrayList<Guitar>();

		for(Instrument i : this.instruments)
		{			
			if(i!=null && i instanceof Guitar)
			{
				Guitar g = (Guitar) i;
				guitars.add(g);
			}
		}
		return guitars;
	}

	public void loadGuitarsFromFile(String fileName)
	{
		List<String> lines = Collections.emptyList();
		ArrayList<Guitar> gui = new ArrayList<>();
		
			try {
				lines = Files.readAllLines(Paths.get("input.txt"), StandardCharsets.UTF_8);
			} catch (IOException e) {
				e.printStackTrace();
			}
		
			for(String lin:lines)
			{
				String[] tokens=lin.split(" ");
				boolean b = Integer.parseInt(tokens[7])!=0;
				instruments.add(new Guitar(Integer.parseInt(tokens[0]),Double.parseDouble(tokens[1]),E_Color.valueOf(tokens[2]) ,Double.parseDouble(tokens[3]),Integer.parseInt(tokens[4]),tokens[5],Integer.parseInt(tokens[6]),b,Integer.parseInt(tokens[8])));
			}
			for(Instrument instru : instruments)
			{
				int count=0;
				if(instru instanceof Guitar)
				{
					if(((Guitar)instru).getNumber()==count)
					{
						System.out.println(instru.toString());
						count++;
					}
				}
			}	
	}

	public void saveGuitarsListToFile(ArrayList<Guitar> guitars)
	{
		String str=" ";
		String str1=" ";
		String str2=" ";
		String str3=" ";
		String str4=" ";
		String str5=" ";
		String str6=" ";
		String str7=" ";
		String str8=" ";
		String str9=" ";
		String str10=" ";
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt", false))) {
			for(Guitar gui:guitars)
			  {
			     try {
			    	 str=gui.toString().replace("Guitar : number=", " ");
			    	 str1=str.replace(", price=", " ");
			    	 str2=str1.replace(", color=", " ");
			    	 str3=str2.replace(", weight=", " ");
			    	 str4=str3.replace(", yearProd=", " ");
			    	 str5=str4.replace(", country=israel", "");
			    	 str6=str5.replace(", numOfInstruments=300", "");
			    	 str7=str6.replace(", numOfInstruments=200", "");
			    	 str8=str7.replace(", numOfInstruments=100", "");
			    	 str9=str8.replace(" isElectric=", " ");
			    	 str10=str9.replace(", numOfStrings=5", " ");
			    	 str10=str10.substring(0,15)+str10.substring(21);
			    	 
					writer.write(str10);
				} catch (IOException e) {
					e.printStackTrace();
				}
			     writer.newLine();
			  }
			  writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

