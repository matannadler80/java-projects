package Core;

public interface IRating {
	public double calcRating();
}
