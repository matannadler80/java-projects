package Core;

public class Guitar extends Instrument implements Comparable<Guitar>{

	private boolean isElectric;

	private int numOfStrings;

	public Guitar(int number, double price, E_Color color, double weight, int yearProd, String country,
			int numOfInstruments,boolean isElectric,int numOfStrings) {
		super(number, price, color, weight, yearProd, country, numOfInstruments);
		this.isElectric=isElectric;
		this.numOfStrings=numOfStrings;
	}

	public boolean isElectric() {
		return isElectric;
	}

	public void setElectric(boolean isElectric) {
		this.isElectric = isElectric;
	}

	public int getNumOfStrings() {
		return numOfStrings;
	}

	public void setNumOfStrings(int numOfStrings) {
		this.numOfStrings = numOfStrings;
	}

	@Override
	public String toString() {
		return "Guitar : "+super.toString()+" isElectric=" + isElectric + ", numOfStrings=" + numOfStrings;
	}

	@Override
	public double calcRating() throws ArithmeticException {
		if(this.numOfInstruments>0)
			return this.price/this.numOfInstruments*10;
		throw new ArithmeticException("Cann't Divide by 0");
	}

	@Override
	public int compareTo(Guitar o) {
		Double d1 =  this.calcRating();
		Double d2 = calcRating();
		return d1.compareTo(d2);
	}






}
