package Core;

public class Piano extends Instrument{

	public boolean isWing;

	public Piano(int number, double price, E_Color color, double weight, int yearProd, String country,
			int numOfInstruments,boolean isWing) {
		super(number, price, color, weight, yearProd, country, numOfInstruments);
		this.isWing=isWing;
	}

	public boolean isWing() {
		return isWing;
	}

	public void setWing(boolean isWing) {
		this.isWing = isWing;
	}

	@Override
	public String toString() {
		return "Piano : "+super.toString()+" + isWing = "+isWing;
	}

	@Override
	public double calcRating() {
		if(this.numOfInstruments>0)
			return this.price/this.numOfInstruments*20;
		return 0;
	}


}
