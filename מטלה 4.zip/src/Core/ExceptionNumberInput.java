package Core;

public class ExceptionNumberInput extends Exception
{
	public ExceptionNumberInput(String msg)
	{
		super(msg);
	}
}
