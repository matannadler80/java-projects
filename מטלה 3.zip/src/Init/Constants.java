package Init;

public class Constants {

	public final static int ordersMaxForAgentOrCustomer=10;

	public final static int agentsPerBranchMax=10;

	public final static int phoneNumbersMax=2;

	public final static int pilotsPerFlight=2;

	public final static int maxTicketsPerOrder=4;

	public final static int maxFlightsPerPilot=10;
	
	public final static int structureSize=100;

}

