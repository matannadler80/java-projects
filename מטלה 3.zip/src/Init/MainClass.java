package Init;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;
import Core.Agent;
import Core.Airplane;
import Core.Branch;
import Core.Customer;
import Core.E_LicenseType;
import Core.Flight;
import Core.FlightTicket;
import Core.FlyWithUs;
import Core.Order;
import Core.Person;
import Core.Pilot;

public class MainClass {
	public static void main(String[] args) throws IOException, ParseException,ClassNotFoundException {
		// the command read from the input file 
		String command;



		// to check if the command updated the objects 
		boolean isUpdated;

		// writer buffer creation used after update 
		MyFileLogWriter.initializeMyFileWriter();

		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		df.setTimeZone(TimeZone.getTimeZone("Asia/Jerusalem"));

		// the fly Object	
		FlyWithUs fly = null;

		// create Scanner for the text file named "input.txt" 
		Scanner input = new Scanner(new File("input.txt"));

		// if the file has next - not empty 
		if (input.hasNext()) {
			fly = new FlyWithUs();			
		}

		/*
		 *  read the commands. loop while input file [input.hasnext()]
		 * and the fly is not null 
		 */
		while (input.hasNext() && fly != null) {

			/* 
			 * read the command, must be first at line because command value 
			 * determine which method will be activated in JEuroTournament object.
			 */
			command = input.next();
			isUpdated = false;

			// ================				Command			================
			if (command.equals("addBranch")) {

				int branchNumber=input.nextInt();
				String branchName=input.next();


				isUpdated = fly.addBranch(new Branch(branchNumber, branchName));

				MyFileLogWriter
				.writeToFileInSeparateLine("addBranch returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Branch " + branchNumber
							+ " to System");
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add new Branch " + branchNumber
							+ " to System");
				}
			}

			// ================				Command			================
			if (command.equals("addCustomer")) {

				int passportNumber=input.nextInt();
				String firstName=input.next();
				String lastName=input.next();
				Date birthDate = df.parse(input.next());


				isUpdated = fly.addCustomer(new Customer(passportNumber, firstName, lastName, birthDate));

				MyFileLogWriter
				.writeToFileInSeparateLine("addCustomer returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Customer " + passportNumber
							+ " to System");
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add new Customer " + passportNumber
							+ " to System");
				}
			}


			// ================				Command			================
			if (command.equals("addAgent")) {

				int passportNumber=input.nextInt();
				String firstName=input.next();
				String lastName=input.next();
				Date birthDate = df.parse(input.next());
				Date joinDate = df.parse(input.next());

				isUpdated = fly.addAgent(new Agent(passportNumber, firstName, lastName, birthDate,joinDate));

				MyFileLogWriter
				.writeToFileInSeparateLine(" returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Agent " + passportNumber
							+ " to System");
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add new Agent " + passportNumber
							+ " to System");
				}
			}
			

			// ================				Command			================
			if (command.equals("addPilot")) {

				int passportNumber=input.nextInt();
				String firstName=input.next();
				String lastName=input.next();
				Date birthDate = df.parse(input.next());
				Date joinDate = df.parse(input.next());
				E_LicenseType e = E_LicenseType.valueOf(input.next());
				isUpdated = fly.addPilot(new Pilot(passportNumber, firstName, lastName, birthDate,joinDate,e));

				MyFileLogWriter
				.writeToFileInSeparateLine(" returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Pilot " + passportNumber
							+ " to System");
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add new Pilot " + passportNumber
							+ " to System");
				}
			}

			// ================				Command			================
			if (command.equals("addFlight")) {
				int flightNumber=input.nextInt();
				Date flightDateAndTimeSource=df.parse(input.next());
				Date flightDateAndTimeDestination=df.parse(input.next());
				double flightCost=input.nextDouble();
				int airplaneNumber=input.nextInt();
				int numberOfSeatsBusinessClass=input.nextInt();
				int numberOfSeatsFirstClass=input.nextInt();
				int numberOfSeatsTouristsClass=input.nextInt();
				String source=input.next();
				String destination=input.next();

				Airplane airplane=new Airplane(airplaneNumber, numberOfSeatsBusinessClass, numberOfSeatsFirstClass, numberOfSeatsTouristsClass);
				Flight f= new Flight(flightNumber, flightDateAndTimeSource, flightDateAndTimeDestination, flightCost, airplane, source, destination);

				isUpdated = fly.addFlightToSystem(f);

				MyFileLogWriter
				.writeToFileInSeparateLine("addFlight returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Flight " + flightNumber
							+ " to System");
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add new Flight " + flightNumber
							+ " to System");
				}
			}

			// ================				Command			================
			if (command.equals("addPilotToFlight")) {
				int flightNumber=input.nextInt();
				int employeeNumber = input.nextInt();
				String firstName = input.next();
				String lastName= input.next();
				Date birthDate=df.parse(input.next());
				Date startWorkingDate=df.parse(input.next());
				String s=input.next();

				Flight f = new Flight(flightNumber);
				Pilot p = new Pilot(employeeNumber, firstName, lastName, birthDate, startWorkingDate,E_LicenseType.valueOf(s));

				isUpdated = fly.addPilotToFlight(p, f);

				MyFileLogWriter
				.writeToFileInSeparateLine("addPilotToFlight returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Pilot to Flight " + flightNumber
							+ " to System");
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add new Pilot to Flight " + flightNumber
							+ " to System");
				}
			}

			// ================				Command			================
			if (command.equals("addOrderToCustomer")) {
				int passportNumber=input.nextInt();
				int custInd = fly.getSystemUsers().indexOf(new Customer(passportNumber,"","",null));
				Customer responsibleCustomer= (Customer) fly.getSystemUsers().get(custInd);
				int orderNumber=input.nextInt();
				int paid=input.nextInt();
				boolean isPaid=false;
				if(paid==1)
					isPaid=true;
				int employeeNumber = input.nextInt();
				String firstName= input.next();
				String lastName= input.next();
				Date birthDate=df.parse(input.next());
				Date startWorkingDate=df.parse(input.next());
				int branchNum = input.nextInt();
				Branch workBranch=new Core.Branch(branchNum);
				Agent agent = new Agent(employeeNumber, firstName, lastName, birthDate, startWorkingDate, workBranch);
				Order o = new Order(orderNumber, isPaid, responsibleCustomer, agent);
				isUpdated = fly.addOrderToCustomer(responsibleCustomer,o, agent);

				MyFileLogWriter
				.writeToFileInSeparateLine("addOrderToCustomer returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added Order :"+orderNumber+ " to Customer : " + passportNumber);
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to added Order :"+orderNumber+ " to Customer : " + passportNumber);

				}
			}


			// ================				Command			================
			if (command.equals("addAgentToBranch")) {


				int employeeNumber = input.nextInt();
				String firstName= input.next();
				String lastName= input.next();
				Date birthDate=df.parse(input.next());
				Date startWorkingDate=df.parse(input.next());
				int branchNum = input.nextInt();
				Branch workBranch=new Core.Branch(branchNum);
				Agent agent = new Agent(employeeNumber, firstName, lastName, birthDate, startWorkingDate, workBranch);				
				isUpdated = fly.addAgentToBranch(agent, workBranch);

				MyFileLogWriter
				.writeToFileInSeparateLine("add Agent To Branch returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added agent :"+employeeNumber+ " to branch :"+branchNum );
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add agent :"+employeeNumber+ " to branch :"+branchNum );

				}
			}

			// ================				Command			================
			if (command.equals("addTicketToFlight")) {


				int orderNumber = input.nextInt();
				int ticketNumber= input.nextInt();
				int passportNumber= input.nextInt();
				int flightNumber= input.nextInt();
				String type=input.next();

				Flight flight = new Flight(flightNumber);
				int custInd = fly.getSystemUsers().indexOf(new Customer(passportNumber,"","",null));
				Customer customer= (Customer) fly.getSystemUsers().get(custInd);

				Order o = new Order(orderNumber);
				isUpdated = fly.addTicketToFlight(o,new FlightTicket(ticketNumber, customer, type, flight));

				MyFileLogWriter
				.writeToFileInSeparateLine("addTicketToFlight returns:");

				if (isUpdated) { // if adding successfully, then true returned,
					// the following message is written to the output file
					MyFileLogWriter
					.writeToFileInSeparateLine("\tSuccessfully added flight ticket to customer :"+passportNumber);
				} else {
					MyFileLogWriter
					.writeToFileInSeparateLine("\tFailed to add flight ticket to customer :"+passportNumber);

				}
			}
		} //~ end of clause - while input has next

		//write queries to output file
		Agent a=null;
		Customer c = null;
		Pilot p1 = null;
		MyFileLogWriter.writeToFileInSeparateLine("Customer With Most Tickets");
		MyFileLogWriter.writeToFileInSeparateLine(fly.customerWithMostTickets().toString());
		MyFileLogWriter.writeToFileInSeparateLine("Get Paid Orders");
		for(Person p : fly.getSystemUsers()) {
			if(p!=null && p instanceof Agent) {
				a = (Agent) p;
				break;
			}
		}
		
		for(Person p : fly.getSystemUsers()) {
			if(p!=null && p instanceof Customer) {
				c = (Customer) p;
				break;
			}
			
		}
		
		for(Person p : fly.getSystemUsers()) {
			
			if(p!=null && p instanceof Pilot) {
				p1 = (Pilot) p;
				break;
			}
		}
		MyFileLogWriter.writeToFileInSeparateLine(fly.getPaidOrders(a).toString());
		MyFileLogWriter.writeToFileInSeparateLine("Find Best Selling Agent");
		MyFileLogWriter.writeToFileInSeparateLine(fly.findBestSellingAgent().toString());
		MyFileLogWriter.writeToFileInSeparateLine("Find All Agents Joined In Month And Year : ");
		MyFileLogWriter.writeToFileInSeparateLine(fly.getAllAgentsJoinedInMonthAndYear(2010,1).toString());
		MyFileLogWriter.writeToFileInSeparateLine("Find All Pilots With License Type X");
		MyFileLogWriter.writeToFileInSeparateLine(fly.getAllPilotsWithLicenseTypeX("Business").toString());

		//more methods
		MyFileLogWriter.writeToFileInSeparateLine("Calc Rating - Pilot");
		MyFileLogWriter.writeToFileInSeparateLine(String.valueOf(p1.calcRating()));
		MyFileLogWriter.writeToFileInSeparateLine("Calc Rating - Customer");
		MyFileLogWriter.writeToFileInSeparateLine(String.valueOf(c.calcRating()));
		MyFileLogWriter.writeToFileInSeparateLine("Calc Rating - Agent");
		MyFileLogWriter.writeToFileInSeparateLine(String.valueOf(a.calcRating()));

		MyFileLogWriter.writeToFileInSeparateLine("Calc Agent's Commision");
		MyFileLogWriter.writeToFileInSeparateLine(String.valueOf(a.calcOrdersTotalPrice()));
		MyFileLogWriter.writeToFileInSeparateLine("Calc Customer Orders Total Price");
		MyFileLogWriter.writeToFileInSeparateLine(String.valueOf(c.calcOrdersTotalPrice()));

		
		MyFileLogWriter.saveLogFile(); // save the output file
		input.close(); // close connection to input file
		System.out.println("[End Of process]");
		System.out.println("\n NOTICE:\n\t\"End of process\" " +
				"does NOT mean that all your methods are correct.\n" +
				"\n==>\t You NEED to check the \"output.txt\" file");




	}

}
