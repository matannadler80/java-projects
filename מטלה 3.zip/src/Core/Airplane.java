package Core;

import java.util.Objects;

/**
 * Class Airplane 
 * @author Roni
 */
public class Airplane {


	//-------------------------------Class Members------------------------------
	/**
	 * The airplane number - the key
	 */
	private int airplaneNumber;
	/**
	 * The number of seats in the business department
	 */
	private int numberOfSeatsBusinessClass;
	/**
	 * The number of seats in the first department
	 */
	private int numberOfSeatsFirstClass;
	/**
	 * The number of seats in the tourists department
	 */
	private int numberOfSeatsTouristsClass;
	
	public Airplane(int airplaneNumber, int numberOfSeatsBusinessClass, int numberOfSeatsFirstClass,
			int numberOfSeatsTouristsClass) {
		this.airplaneNumber = airplaneNumber;
		this.numberOfSeatsBusinessClass = numberOfSeatsBusinessClass;
		this.numberOfSeatsFirstClass = numberOfSeatsFirstClass;
		this.numberOfSeatsTouristsClass = numberOfSeatsTouristsClass;
	}
	public int getAirplaneNumber() {
		return airplaneNumber;
	}
	public void setAirplaneNumber(int airplaneNumber) {
		this.airplaneNumber = airplaneNumber;
	}
	public int getNumberOfSeatsBusinessClass() {
		return numberOfSeatsBusinessClass;
	}
	public void setNumberOfSeatsBusinessClass(int numberOfSeatsBusinessClass) {
		this.numberOfSeatsBusinessClass = numberOfSeatsBusinessClass;
	}
	public int getNumberOfSeatsFirstClass() {
		return numberOfSeatsFirstClass;
	}
	public void setNumberOfSeatsFirstClass(int numberOfSeatsFirstClass) {
		this.numberOfSeatsFirstClass = numberOfSeatsFirstClass;
	}
	public int getNumberOfSeatsTouristsClass() {
		return numberOfSeatsTouristsClass;
	}
	public void setNumberOfSeatsTouristsClass(int numberOfSeatsTouristsClass) {
		this.numberOfSeatsTouristsClass = numberOfSeatsTouristsClass;
	}
	@Override
	public int hashCode() {
		return Objects.hash(airplaneNumber);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Airplane other = (Airplane) obj;
		return airplaneNumber == other.airplaneNumber;
	}
	@Override
	public String toString() {
		return "Airplane [airplaneNumber=" + airplaneNumber + ", numberOfSeatsBusinessClass="
				+ numberOfSeatsBusinessClass + ", numberOfSeatsFirstClass=" + numberOfSeatsFirstClass
				+ ", numberOfSeatsTouristsClass=" + numberOfSeatsTouristsClass + "]";
	}

	
	
}
