package Core;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

import Init.Constants;

/**
 * Class Flight ~ represent a single flight in system
 * @author Roni
 */
public class Flight {

	//-------------------------------Class Members------------------------------
	/**
	 * The flight number
	 */
	private int flightNumber;
	/**
	 * The time when the flight departuere from the source
	 */
	private Date flightDateAndTimeSource;
	/**
	 * The time when the flight land in the destination
	 */
	private Date flightDateAndTimeDestination;
	/**
	 * The cost for this flight
	 */
	private double flightCost;
	/**
	 * The pilots for this flight
	 */
	private ArrayList<Pilot> pilots;

	/**
	 * This flight airplane
	 */
	private Airplane airplane;
	/**
	 * The flight source airport
	 */
	private String source;

	/**
	 * The flight destination airport
	 */
	private String destination;

	private ArrayList<FlightTicket> tickets;


	public Flight(int flightNumber, Date flightDateAndTimeSource, Date flightDateAndTimeDestination, double flightCost,
			Airplane airplane, String source, String destination) {
		this.flightNumber = flightNumber;
		this.flightDateAndTimeSource = flightDateAndTimeSource;
		this.flightDateAndTimeDestination = flightDateAndTimeDestination;
		this.flightCost = flightCost;
		this.airplane = airplane;
		this.source = source;
		this.destination = destination;
		this.pilots=new ArrayList<Pilot>(Constants.pilotsPerFlight);
		int sum = this.airplane.getNumberOfSeatsBusinessClass()+this.airplane.getNumberOfSeatsFirstClass()+this.airplane.getNumberOfSeatsTouristsClass();
		this.tickets=new ArrayList<FlightTicket>(sum);
	}

	
	
	public Flight(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	


	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public Date getFlightDateAndTimeSource() {
		return flightDateAndTimeSource;
	}

	public void setFlightDateAndTimeSource(Date flightDateAndTimeSource) {
		this.flightDateAndTimeSource = flightDateAndTimeSource;
	}

	public Date getFlightDateAndTimeDestination() {
		return flightDateAndTimeDestination;
	}

	public void setFlightDateAndTimeDestination(Date flightDateAndTimeDestination) {
		this.flightDateAndTimeDestination = flightDateAndTimeDestination;
	}

	public double getFlightCost() {
		return flightCost;
	}

	public void setFlightCost(double flightCost) {
		this.flightCost = flightCost;
	}
	public Airplane getAirplane() {
		return airplane;
	}

	public void setAirplane(Airplane airplane) {
		this.airplane = airplane;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}
	

	public ArrayList<Pilot> getPilots() {
		return pilots;
	}



	public void setPilots(ArrayList<Pilot> pilots) {
		this.pilots = pilots;
	}



	public ArrayList<FlightTicket> getTickets() {
		return tickets;
	}



	public void setTickets(ArrayList<FlightTicket> tickets) {
		this.tickets = tickets;
	}



	@Override
	public int hashCode() {
		return Objects.hash(flightNumber);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		return flightNumber == other.flightNumber;
	}



	public boolean addPilot(Pilot pilot)
	{
		if(pilot!=null && this.pilots.size()<Constants.pilotsPerFlight)
		{
			this.pilots.add(pilot);
			return true;
		}
		return false;
	}

	public boolean addTicket(FlightTicket ft) {
		if(ft==null && this.tickets.size()<Constants.structureSize)
		{
			for(FlightTicket fl : this.tickets)
			{
				if(this.tickets.contains(null))
				{
					continue;
				}
				if( ft!=null && fl.getTicketNumber()==ft.getTicketNumber())
				{
				return false;
				}
			else 
			{
				this.tickets.add(ft);
				return true;
				
			}
		}
		}
		return false;
	}

	@Override
	public String toString() {
		return "Flight [flightNumber=" + flightNumber + ", flightDateAndTimeSource=" + flightDateAndTimeSource
				+ ", flightDateAndTimeDestination=" + flightDateAndTimeDestination + ", flightCost=" + flightCost
				+ ", source=" + source + ", destination=" + destination + "]";
	}


	
}
