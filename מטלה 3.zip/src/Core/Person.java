package Core;

import java.util.Date;
import java.util.Objects;

public abstract class Person
{
	private int id;
	private String firstName;
	private String lastName;
	private Date bitrhDate;
	public abstract double calcRating();
	
	public Person(int id, String firstName, String lastName, Date bitrhDate) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.bitrhDate = bitrhDate;
	}
	
	public Person(int id)
	{ 
		setId(id);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBitrhDate() {
		return bitrhDate;
	}

	public void setBitrhDate(Date bitrhDate) {
		this.bitrhDate = bitrhDate;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", bitrhDate=" + bitrhDate
				+ "]";
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return id == other.id;
	}
	
	
	
	

}
