package Core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;
import Init.Constants;
/**
 * Class Order ~ represent the order of customer 
 * @author Roni
 */
public class Order implements Comparable<Order>{

	//-------------------------------Class Members------------------------------
	/**
	 * The order number - the key
	 */
	private int orderNumber;
	/**
	 * The order status - can be true(paid) or by default false(unpaid)
	 */
	private boolean isPaid;
	/**
	 * The customer who made this order
	 */
	private Customer responsibleCustomer;

	/**
	 * The employee (Agent) that handle this order
	 */
	private Agent agent;

	private ArrayList<FlightTicket> orderTickets;

	public Order(int orderNumber, boolean isPaid, Customer responsibleCustomer, Agent agent) {
		this.orderNumber = orderNumber;
		this.isPaid = isPaid;
		this.responsibleCustomer = responsibleCustomer;
		this.agent = agent;
		this.orderTickets=new ArrayList<FlightTicket>(Constants.maxTicketsPerOrder);
	}

	public Order(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	


	public ArrayList<FlightTicket> getOrderTickets() {
		return orderTickets;
	}

	public void setOrderTickets(ArrayList<FlightTicket> orderTickets) {
		this.orderTickets = orderTickets;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public boolean isPaid() {
		return isPaid;
	}

	public void setPaid(boolean isPaid) {
		this.isPaid = isPaid;
	}

	public Customer getResponsibleCustomer() {
		return responsibleCustomer;
	}

	public void setResponsibleCustomer(Customer responsibleCustomer) {
		this.responsibleCustomer = responsibleCustomer;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return orderNumber == other.orderNumber;
	}



	public boolean addTicket(FlightTicket ft)
	{
		if(ft==null && this.orderTickets.size()<Constants.maxTicketsPerOrder)
		{
			for(FlightTicket fl:this.orderTickets)
			{
				if(this.orderTickets.contains(null))
				{
					continue;
				}
			if(fl!=null && ft!=null && fl.getTicketNumber()==ft.getTicketNumber())
			{
				return false;
			}
			this.orderTickets.add(ft);
			return true;
			}
		}
		return false;
			
	}

	public double orderCost() {
		double sum=0;
		double ticketPrice=0;
		for(FlightTicket ft : this.orderTickets) {
			if(ft!=null) {
				if(ft.getClassType().equals("Tourists")) {
					ticketPrice=ft.calcTicketCost();
					sum=sum+ticketPrice;
				}
				else if(ft.getClassType().equals("First")) {
					ticketPrice=ft.calcTicketCost();
					sum=sum+ticketPrice;
				}
				else if(ft.getClassType().equals("Business")) {
					ticketPrice=ft.calcTicketCost();
					sum=sum+ticketPrice;
				}
			}
		}
		
		return sum;
	}

	@Override
	public String toString() {
		return "Order [orderNumber=" + orderNumber + ", isPaid=" + isPaid + ", order cost=" + orderCost() + "]";
	}

	@Override
	public int compareTo(Order o) 
	{
		if(this.getOrderNumber()<o.getOrderNumber())
		{
			return -1;
		}
		else if(this.getOrderNumber()>o.getOrderNumber())
		{
			return 1;
		}
		return 0;
	}

	



	








}
