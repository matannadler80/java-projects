package Core;

import java.util.*;




public class FlyWithUs {

	private ArrayList<Branch> branches;

	private ArrayList<Order> orders;

	private ArrayList<Flight> flights;

	private ArrayList<Person> systemUsers;
	

	public FlyWithUs() {
		this.branches=new ArrayList<Branch>();
		this.orders=new ArrayList<Order>();
		this.flights=new ArrayList<Flight>();
		this.systemUsers=new ArrayList<Person>();
		

	}
	

	//-------------------------------------Methods-----------------------------------------------//


	public ArrayList<Branch> getBranches() {
		return branches;
	}


	public void setBranches(ArrayList<Branch> branches) {
		this.branches = branches;
	}


	public ArrayList<Order> getOrders() {
		return orders;
	}


	public void setOrders(ArrayList<Order> orders) {
		this.orders = orders;
	}


	public ArrayList<Flight> getFlights() {
		return flights;
	}


	public void setFlights(ArrayList<Flight> flights) {
		this.flights = flights;
	}
	
	
	//-------------------------------------Methods-----------------------------------------------//


	public ArrayList<Person> getSystemUsers() {
		return systemUsers;
	}


	public void setSystemUsers(ArrayList<Person> systemUsers) {
		this.systemUsers = systemUsers;
	}


	public boolean addPilotToFlight(Pilot p , Flight f) {
		if(p!=null && f!=null) {
			for(Flight flight : this.flights) {
				if(flight!=null && flight.equals(f)) {
					if(flight.addPilot(p)) {
						for(Pilot pl:flight.getPilots()) {
							if(pl.addFlight(f))
								return true;
							return false;
						}
					}
					return false;
				}
			}
			return false;
		}
		return false;
	}

	public boolean addOrderToCustomer(Customer cust,Order o,Agent a) {
		int flgCust=-1;
		if(cust!=null && o!=null && a!=null) 
		{

			for(Person c:this.systemUsers)
			{
				if(c!=null && c instanceof Customer && c.equals(cust))
				{
					flgCust=1;
					break;
				}
			}

			if(flgCust==1)
			{
				for(Person c : this.systemUsers)
				{
					if(c!=null && c instanceof Customer && c.equals(cust))
					{
						((Customer)c).addOrder(o);
					}
				}
				o.setAgent(a);
				o.setResponsibleCustomer(cust);
				for(Order or: this.orders) {
					if(or==null) {
						or=o;
						break;
					}
				}

				for(Branch b: this.branches) {
					if(b!=null) {
						for(Agent ag:b.getBranchAgents()) {
							if(ag!=null && ag.equals(a)) {
								ag.addOrder(o);
								break;
							}
						}
					}
				}
				return true;
			}
			return false;
		}
		return false;
	}

	public boolean addFlightToSystem(Flight f) {
		if(f==null) 
			return false;

		for(Flight fl: this.flights) {
			if(fl!=null && fl.equals(f)) {
				return false;
			}
			if(fl==null) {
				fl=f;
				return true;
			}
		}
		return false;
	}

	public boolean addCustomer(Customer c) {
		if(c==null) 
			return false;

		for(Person cus: this.systemUsers) 
		{
			if(cus!=null && (cus instanceof Customer) && cus.equals(c)) {
				return false;
			}
			if(cus==null) {
				cus=c;
				return true;
			}
		}
		return false;
	}

	public boolean addBranch(Branch b)
	{
		if(b==null)
		{
			return false;
		}
		for(Branch br: this.branches)
		{
			if(br!=null && br.equals(b))
			{
				return false;
			}
			if(br==null && !branches.contains(b))
			{
				br=b;
				return true;
			}
		}
		return false;
	}
	public boolean removeOrderFromSystem(Order o) {
		if(o!=null) {
			for(Order or:this.orders)
			{
				if(or!=null && or.equals(o))
				{
					if(!or.isPaid())
					{
						for(FlightTicket f: or.getOrderTickets())
						{
							if(f!=null)
							return false;
						}
						or=null;
						for(Person c:this.systemUsers) {
							if(c!=null && c instanceof Customer)
								((Customer)c).removeOrder(o);
						}
						for(Branch b: this.branches) {
							if(b!=null) {
								for(Agent a : b.getBranchAgents()) {
									if(a!=null) {
										a.removeOrder(o);
										break;
									}
								}
							}
						}
						return true;
					}
					return false;
				}
			}
			return false;
		}
		return false;
	}


	public boolean addAgentToBranch(Agent a,Branch b) {
		if(a==null || b==null)
			return false;

		for(Branch br: this.branches) {
			if(br!=null) {
				for(Agent ag:br.getBranchAgents()) {
					if(ag!=null && ag.equals(a)) {
						return false;
					}
				}
			}
		}
		a.setWorkBranch(b);
		for(Branch br1:this.branches) {
			if(br1!=null && br1.equals(b)) {
				br1.addAgent(a);
				return true;
			}
		}
		return false;
	}

	public boolean addTicketToFlight(Order order,FlightTicket ft) {
		int orderInd=0;
		Flight fl1=null;
		if(order!=null && ft!=null) {
			for(Order o : this.orders) {
				if(o.equals(order)) {
					orderInd=1;
					break;
				}
			}

			if(orderInd==1) {
				for(Flight f1 : this.flights) {
					if(f1!=null && f1.equals(ft.getFlight())) {
						fl1=f1;
						break;
					}
				}
				ft.setFlight(fl1);
				for(Order o : this.orders) {
					if(o.addTicket(ft)) {
						for(Flight f : this.flights) {
							if(f.equals(ft.getFlight())) {
								f.addTicket(ft);
								return true;
							}
						}
						return false;
					}
					return false;
				}
			}
			return false;
		}
		return false;

	}
	
	public boolean addPilot(Pilot pl)
	{
		if(pl==null) 
			return false;

		for(Person pil: this.systemUsers) 
		{
			if(pil!=null && (pil instanceof Pilot) && pil.equals(pl)) {
				return false;
			}
			if(pil==null) {
				pil=pl;
				return true;
			}
		}
		return false;
	}
	
	public boolean addAgent(Agent a)
	{
		if(a==null) 
			return false;

		for(Person ag: this.systemUsers) 
		{
			if(ag!=null && (ag instanceof Agent) && ag.equals(a)) {
				return false;
			}
			if(ag==null) {
				ag=a;
				return true;
			}
		}
		return false;
	}


	//-------------------------------------Queries-----------------------------------------------//
	public Branch findBranchWithMostAgents() {
		int max =-1;
		int sum=0;
		Branch br=null;
		for(Branch b:this.branches) {
			if(b!=null) {
				for(Agent a:b.getBranchAgents()) {
					if(a!=null) {
						sum++;
						
					}
				}
				if(sum>=max) {
					max=sum;
					br=b;
				}
				sum=0;
			}
		}
		return br;
	}


	public String findCustomersByFName(String fName) {
		String s="";
		for(Person c : this.systemUsers) {
			if(c!=null &&  c instanceof Customer && c.getFirstName().equals(fName)) {
				s=s+c+"\n";
			}
		}
		return s;
	}

	public Order mostExspensiveOrder() {
		Order or =null;
		double max =-1;
		for(Order o : this.orders) {
			if(o!=null && o.orderCost()>=max) {
				or=o;
				max=o.orderCost();
			}
		}

		return or;
	}

	public Customer customerWithMostTickets() {
		Customer cust=null;
		int max =-1;
		int sum=0;
		for(Person c: this.systemUsers)
		{
			if(c!=null && c instanceof Customer)
			{
				sum=0;
				for(Order o : ((Customer)c).getCustOrders()) {
					if(o!=null) {
						for(FlightTicket ft:o.getOrderTickets()) {
							if(ft!=null) {
								sum=sum+1;
							}
						}
					}
				}
				if(sum>=max) {
					max=sum;
					cust=(Customer)c;
				}
			}
		}
		return cust;

	}


	public Flight mostProfitableFlight() {
		Flight f =null;
		double sum=0;
		double max =-1;
		for(Flight fl : this.flights) {
			if(fl!=null) {
				for(FlightTicket ft : fl.getTickets()) {
					if(ft!=null)
					sum=sum+ft.calcTicketCost();
				}
				if(sum>=max) {
					max=sum;
					f=fl;
				}
				sum=0;
			}
		}
		return f;
	}
	
	public ArrayList<Order> getPaidOrders(Agent agent)
	{
		if(agent!=null)
		{
		ArrayList<Order> isPayed = new ArrayList<>();
		for(Order or:agent.getAgentOrders())
		{
			if(or.isPaid() && or!=null)
			{
				isPayed.add(or);
			}
		}
		Collections.sort(isPayed,new Comparator<Order>() {
			public int compare(Order p1 , Order p2) {
				Integer ord1 = p1.getOrderNumber();
				Integer ord2 = p2.getOrderNumber();
				return ord2.compareTo(ord1);
			}
		});
		return isPayed;
		}
		return null;
		
	}
	
	public Agent findBestSellingAgent ()
	{
		int count=0;
		int max=0;
		Agent agent =null;
		for(Person ag: this.systemUsers)
		{
			if(ag!=null && ag instanceof Agent)
			{
				for(Order ord:((Agent)ag).getAgentOrders())
				{
					if(ord!=null && ord.isPaid())
					{
						count++;
					}
				}
				if(count>max)
				{
					max=count;
					agent=((Agent)ag);
				}
			}
		}
		return agent;
	}
	
	public ArrayList<Agent> getAllAgentsJoinedInMonthAndYear(int year,int month)
	{
		ArrayList<Agent> calendarAgent = new ArrayList<>();
		ArrayList<String> agNames = new ArrayList<>();
		ArrayList<Agent> sortedAgents = new ArrayList<>();
		for(Person ag:this.systemUsers)
		{
			if(ag!=null && ag instanceof Agent)
			{
				Calendar calender = Calendar.getInstance();
				calender.setTime(((Agent)ag).getStartWorkingDate());
				int agMonth=calender.get(Calendar.MONTH)+1;
				int agYear=calender.get(Calendar.YEAR);
				
				if(agMonth==month && agYear==year)
				{
					agNames.add(((Agent)ag).getFirstName());
					calendarAgent.add(((Agent)ag));
				}
			}
		Collections.sort(agNames);
		for(String names:agNames)
		{
			for(Agent age:calendarAgent)
			{
				if(names==age.getFirstName())
				{
					sortedAgents.add(age);
				}
			}
		}
		
	}
		return sortedAgents;
	}
	
	public ArrayList<Pilot> getAllPilotsWithLicenseTypeX(String licenseType)
	{
		ArrayList<Pilot> pilots = new ArrayList<>();
		for(Person pil:this.systemUsers)
		{
			if(pil!= null && pil instanceof Pilot)
			{
				if(licenseType.equalsIgnoreCase(((Pilot)pil).getLicenseType().toString()))
				{
					pilots.add(((Pilot)pil));
				}
			}
		}
		Collections.sort(pilots,new Comparator<Pilot>() {
			public int compare(Pilot p1 , Pilot p2) {
				Integer pil1 = p1.getFlights().size();
				Integer pil2 = p2.getFlights().size();
				return pil1.compareTo(pil2);
			}
		});
		return pilots;
	}




}
