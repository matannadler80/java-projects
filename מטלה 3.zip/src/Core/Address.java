package Core;

import java.util.Objects;

/**
 * Class Address ~ represent the address used by some entities in the system
 * @author Roni
 */
public class Address  {

	//-------------------------------Class Members------------------------------
	/**
	 * country
	 */
	private String country;
	/**
	 * city
	 */
	private String city;
	/**
	 * street
	 */
	private String street;
	/**
	 * house number 
	 */
	private int houseNumber;

	/**
	 * zip code
	 */
	private int zipCode;


	public Address(String country, String city, String street, int houseNumber, int zipCode) {
		this.country = country;
		this.city = city;
		this.street = street;
		this.houseNumber = houseNumber;
		this.zipCode = zipCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	public int hashCode() {
		return Objects.hash(city, street, zipCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return Objects.equals(city, other.city) && Objects.equals(street, other.street) && zipCode == other.zipCode;
	}

	@Override
	public String toString() {
		return "country=" + country + ", city=" + city + ", street=" + street + ", houseNumber=" + houseNumber
				+ ", zipCode=" + zipCode;
	}




	
}
