package Core;

import java.util.Objects;

public class FlightTicket {

	private int ticketNumber;
	
	private Customer customer;
	
	private String classType;
	
	private Flight flight;

	public FlightTicket(int ticketNumber, Customer customer, String classType, Flight flight) {
		this.ticketNumber = ticketNumber;
		this.customer = customer;
		this.classType = classType;
		this.flight = flight;
	}

	public int getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(int ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	@Override
	public int hashCode() {
		return Objects.hash(classType, customer, flight, ticketNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightTicket other = (FlightTicket) obj;
		return classType == other.classType && Objects.equals(customer, other.customer)
				&& Objects.equals(flight, other.flight) && ticketNumber == other.ticketNumber;
	}


	
	public double calcTicketCost() {
		double ticketPrice=0;
		if(classType.equals("Tourists")) {
			ticketPrice=flight.getFlightCost();
			
		}
		else if(classType.equals("First")) {
			ticketPrice=flight.getFlightCost()*1.2;
		}
		else if(classType.equals("Business")) {
			ticketPrice=flight.getFlightCost()*1.4;
		}
		return ticketPrice;
	}

	@Override
	public String toString() {
		return "FlightTicket [ticketNumber=" + ticketNumber + ", classType=" + classType + "]";
	}


	
}
