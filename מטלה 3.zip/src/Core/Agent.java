package Core;

import java.time.LocalDate;
import java.time.Year;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import Init.Constants;
import java.util.GregorianCalendar;

/**
 * Class Agent ~ represent the employee that responsible 
 * for order handling and produce flight tickets
 * @author Roni
 */
public class Agent extends Person  {

	/**
	 * The date when this employee started work in the company
	 */
	private Date startWorkingDate;

	/**
	 * All agent's orders
	 */
	private ArrayList<Order> agentOrders;

	/**
	 * The branch where this agent work in
	 */
	private Branch workBranch;

	private int numOfCurrentOrders;
	
	public double calcRating()
	{
		Calendar calender = Calendar.getInstance();
		calender.setTime(super.getBitrhDate());
		int month=calender.get(Calendar.MONTH)+1;
		return (this.getFirstName().length()/2)*month+30;
	}
	
	
	

	public Agent(int id, String firstName, String lastName, Date bitrhDate, Date startWorkingDate,
			ArrayList<Order> agentOrders, Branch workBranch, int numOfCurrentOrders)
	{
		super(id, firstName, lastName, bitrhDate);
		this.startWorkingDate = startWorkingDate;
		this.agentOrders = agentOrders;
		this.workBranch = workBranch;
		this.numOfCurrentOrders = 0;
	}

	public Agent(int id,String firstName, String lastName, Date bitrhDate, Date startWorkingDate)
	{
		super(id, firstName, lastName, bitrhDate);
		this.startWorkingDate=startWorkingDate;
		
	}
	
	public Agent(int id,String firstName, String lastName, Date bitrhDate, Date startWorkingDate,Branch workBranch)
	{
		super(id, firstName, lastName, bitrhDate);
		this.startWorkingDate=startWorkingDate;
		this.workBranch = workBranch;
	}
	

	public Date getStartWorkingDate() {
		return startWorkingDate;
	}




	public void setStartWorkingDate(Date startWorkingDate) {
		this.startWorkingDate = startWorkingDate;
	}




	public ArrayList<Order> getAgentOrders() {
		return agentOrders;
	}




	public void setAgentOrders(ArrayList<Order> agentOrders) {
		this.agentOrders = agentOrders;
	}




	public Branch getWorkBranch() {
		return workBranch;
	}




	public void setWorkBranch(Branch workBranch) {
		this.workBranch = workBranch;
	}




	public int getNumOfCurrentOrders() {
		return numOfCurrentOrders;
	}




	public void setNumOfCurrentOrders(int numOfCurrentOrders) {
		this.numOfCurrentOrders = numOfCurrentOrders;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agent other = (Agent) obj;
		return super.getId()==other.getId();
	}
	
	


	@Override
	public String toString() {
		return "Agent [" +super.toString()+ startWorkingDate + ", agentOrders=" + agentOrders + ", workBranch="
				+ workBranch + ", numOfCurrentOrders=" + numOfCurrentOrders + "]";
	}




	public boolean addOrder(Order o) {
		if(o!=null)
		{
			this.agentOrders.add(o);
			this.numOfCurrentOrders++;
			return true;
		}
		return false;
	}

	public boolean removeOrder(Order o) {
		if(o==null)
			return false;
		
		for(Order or : this.agentOrders)
		{
			if(o.equals(or))
			{
				or=null;
				this.numOfCurrentOrders--;
				return true;
			}
		}
		return false;
	}
	
	public double calcOrdersTotalPrice()
	{
		double amlaOne=1.1;
		double amlaTwo=1.15;
		double totalSum=0;
		
		ZoneId timeZone = ZoneId.systemDefault();
		LocalDate getLocalDate = getStartWorkingDate().toInstant().atZone(timeZone).toLocalDate();
		int year = Year.now().getValue();
		int agYear=getLocalDate.getYear();
		
		for(Order or:this.agentOrders)
		{
			totalSum=totalSum+or.orderCost();
		}
		if(year-agYear<5)
		{
			totalSum=totalSum*amlaOne;
			return totalSum;
		}
		else
		{
			totalSum=totalSum*amlaTwo;
			return totalSum;
		}
	}
	
	public int numOfPaidOrders()
	{
		int count=0;
		for(Order or:agentOrders)
		{
			if(or!=null && or.isPaid())
			{
				count++;
			}
		}
		return count;
		
	}




	

	
} 
