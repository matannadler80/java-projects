package Core;

import java.text.SimpleDateFormat;

import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import Init.Constants;

/**
 * Class Customer ~ represent the entity who responsible to order flights 
 * @author Roni
 */
public class Customer extends Person {
	
	//-------------------------------Class Members------------------------------
	
	
	
	
	/**
	 * Customer's address
	 */
	private Address customerAddress;
	
	/**
	 * Customer's orders - as a responsible customer
	 */
	private ArrayList<Order> custOrders;
	
	/**
	 * The phone number
	 */
	private String[] phoneNumber;
	
	private int numOfCurrentOrders;
	
	public double calcRating()
	{
		Calendar calender = Calendar.getInstance();
		calender.setTime(super.getBitrhDate());
		int month=calender.get(Calendar.MONTH)+1;
		return (this.getFirstName().length()/2)*month+20;
	}
	
	

	public Customer(int id, String firstName, String lastName, Date bitrhDate, Address customerAddress,
			ArrayList<Order> custOrders, String[] phoneNumber, int numOfCurrentOrders)
	{
		super(id, firstName, lastName, bitrhDate);
		this.customerAddress = customerAddress;
		this.custOrders = custOrders;
		this.phoneNumber = phoneNumber;
		this.numOfCurrentOrders = numOfCurrentOrders;
	}
	public Customer(int id,String firstName,String lastName,Date birthDate)
	{
		super(id,firstName,lastName,birthDate);
	}



	public Address getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(Address customerAddress) {
		this.customerAddress = customerAddress;
	}
	public ArrayList<Order> getCustOrders() {
		return custOrders;
	}


	public void setCustOrders(ArrayList<Order> custOrders) {
		this.custOrders = custOrders;
	}


	public int getNumOfCurrentOrders() {
		return numOfCurrentOrders;
	}


	public void setNumOfCurrentOrders(int numOfCurrentOrders) {
		this.numOfCurrentOrders = numOfCurrentOrders;
	}


	public String[] getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String[] phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return super.getId()==other.getId();
	}



	@Override
	public String toString() {
		return "Customer [passportNumber=" + super.getId() + ", firstName=" + super.getFirstName() + ", lastName=" + super.getLastName()
				+ ", birthDate=" + super.getBitrhDate() + "]";
	}


	public boolean addOrder(Order o) {
		if(o!=null) {
			this.custOrders.add(o);
			this.numOfCurrentOrders++;
			return true;
		}
		return false;
	}

	public boolean removeOrder(Order o) {
		if(o==null)
			return false;
		
		for(Order or : this.custOrders) {
			if(o.equals(or)) {
				or=null;
				this.numOfCurrentOrders--;
				return true;
			}
		}
		return false;
	}

	public boolean addPhoneNumber(String phone) {
		if(phone!=null && phone.length()==10) {
			if(this.phoneNumber[0]==null) {
				this.phoneNumber[0]=phone;
				return true;
			}
			else if (this.phoneNumber[1]==null) {
				this.phoneNumber[1]=phone;
				return true;
			}
			else {
				this.phoneNumber[0]=phone;
				return true;
			}
		}
		return false;
	}
	
	public double calcOrdersTotalPrice()
	{
		double totalSum=0;
		double discount=0.95;
		
		for(Order or:this.custOrders)
		{
			totalSum=totalSum+or.orderCost();
		}
		totalSum=totalSum*discount;
		return totalSum;
	}
	
	
}
