package Core;

import java.util.ArrayList;

import java.util.Objects;


/**
 * Class Branch ~ represent a single branch of the company
 * @author Roni
 */
public class Branch {

	//-------------------------------Class Members------------------------------
	/**
	 * Branch's number - the key
	 */
	private int branchNumber;
	/**
	 * Branch's name
	 */
	private String branchName;
	/**
	 * All branch's orders
	 */
	private ArrayList<Agent> branchAgents;

	public Branch(int branchNumber, String branchName) {
		this.branchNumber = branchNumber;
		this.branchName = branchName;
		
	}

	public Branch(int branchNumber)
	{
		this.branchNumber = branchNumber;
	}


	public int getBranchNumber() {
		return branchNumber;
	}

	public void setBranchNumber(int branchNumber) {
		this.branchNumber = branchNumber;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public ArrayList<Agent> getBranchAgents() {
		return branchAgents;
	}

	public void setBranchAgents(ArrayList<Agent> branchAgents) {
		this.branchAgents = branchAgents;
	}

	@Override
	public int hashCode() {
		return Objects.hash(branchNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Branch other = (Branch) obj;
		return branchNumber == other.branchNumber;
	}

	

	@Override
	public String toString() {
		return "Branch [branchNumber=" + branchNumber + ", branchName=" + branchName + "]";
	}

	public boolean addAgent(Agent a) {		
		if(a!=null)
		{
			this.branchAgents.add(a);
			return true;
		}
		return false;
	}
	
	public ArrayList<Order> getOrders()
	{
		ArrayList<Order> brOrd=new ArrayList<>();
		for(Agent ag:branchAgents)
		{
			for(Order or:ag.getAgentOrders())
			{
				if(or!=null)
				{
					brOrd.add(or);
				}		
		}
	}
		return brOrd;
	}
}
