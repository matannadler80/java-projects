package Core;

public enum E_LicenseType
{
	Private,Business,Special;

}
