package Core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import Init.Constants;

/**
 * Class Pilot ~ represent one of our company pilots
 * @author Roni
 */

public class Pilot extends Person implements Comparable<Pilot>{

	
	//-------------------------------Class Members------------------------------
	/**
	 * The date when this employee started work in the company
	 */
	private Date startWorkingDate;

	/**
	 * The pilot license type
	 */
	private E_LicenseType licenseType;
	
	/**
	 * This pilot's flights
	 */
	private ArrayList<Flight> flights;
	
	public double calcRating()
	{
		Calendar calender = Calendar.getInstance();
		calender.setTime(super.getBitrhDate());
		int month=calender.get(Calendar.MONTH)+1;
		return (this.getFirstName().length()/2)*month;
	}

	

	public Pilot(int id, String firstName, String lastName, Date bitrhDate, Date startWorkingDate, E_LicenseType licenseType,
			ArrayList<Flight> flights)
	{
		super(id, firstName, lastName, bitrhDate);
		this.startWorkingDate = startWorkingDate;
		this.licenseType=licenseType;
		this.flights = new ArrayList<Flight>();
	}
	public Pilot(int id, String firstName, String lastName, Date bitrhDate, Date startWorkingDate, E_LicenseType licenseType)
	{
		super(id, firstName, lastName, bitrhDate);
		this.startWorkingDate = startWorkingDate;
		this.licenseType=licenseType;
	}
	
	

	public Date getStartWorkingDate() {
		return startWorkingDate;
	}

	public void setStartWorkingDate(Date startWorkingDate) {
		this.startWorkingDate = startWorkingDate;
	}

	public E_LicenseType getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(E_LicenseType licenseType) {
		this.licenseType = licenseType;
	}
	
	public ArrayList<Flight> getFlights() {
		return flights;
	}
	
	public void setFlights(ArrayList<Flight> flights) {
		this.flights = flights;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pilot other = (Pilot) obj;
		return super.getId() == other.getId();
	}



	public boolean addFlight(Flight f) {
		if(f!=null && this.flights.size()<Constants.maxFlightsPerPilot)
		{
			for(Flight fl: this.flights)
			{
				if(fl==null)
				{
					this.flights.add(f);
					return true;
				}
			}
			return false;
		}
		return false;
	}

	@Override
	public String toString() {
		return "Pilot ["+super.toString() + " startWorkingDate=" + startWorkingDate + ", licenseType=" + licenseType
				+ "]";
	}



	@Override
	public int compareTo(Pilot o)
	{
		if(this.getFlights().size()<o.getFlights().size())
		{
			return -1;
		}
		else if(this.getFlights().size()<o.getFlights().size())
		{
			return 1;
		}
		return 0;
	}

	
	
	
}